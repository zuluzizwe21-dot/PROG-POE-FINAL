/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.poepart1;

import java.util.Scanner;

public class PoePart1 {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // --- PART 3 SETUP ---
        StoredMessagesManager.populateTestData();
        StoredMessagesManager.loadStoredMessagesFromJSON();
        // --------------------

        // --- PART 1: REGISTRATION & LOGIN ---
        System.out.println("=== Chat App Registration ===");
        System.out.print("Enter first name: ");
        String firstName = scanner.nextLine();

        System.out.print("Enter last name: ");
        String lastName = scanner.nextLine();

        System.out.print("Enter username (must contain _ and be <= 5 chars): ");
        String username = scanner.nextLine();

        System.out.print("Enter password (min 8 chars, 1 capital, 1 number, 1 special): ");
        String password = scanner.nextLine();

        System.out.print("Enter SA cell number (format: +27831234567): ");
        String cellPhone = scanner.nextLine();

        Registration registration = new Registration();
        String registerResult = registration.registerUser(
                firstName, lastName, username, password, cellPhone);
        System.out.println("\n" + registerResult);

        if (registration.getUsername() == null) {
            System.out.println("Registration failed. Exiting.");
            scanner.close();
            return;
        }

        Login login = new Login();
        login.setCredentials(
                registration.getFirstName(),
                registration.getLastName(),
                registration.getUsername(),
                registration.getPassword());

        System.out.println("\n=== Login ===");
        int attempts = 0;
        boolean success = false;

        while (attempts < 3 && !success) {
            System.out.print("Enter username: ");
            String loginUser = scanner.nextLine();
            System.out.print("Enter password: ");
            String loginPass = scanner.nextLine();

            success = login.loginUser(loginUser, loginPass);
            System.out.println(login.returnLoginStatus(success));

            if (!success) {
                attempts++;
                if (attempts < 3) {
                    System.out.println("Try again. Attempts remaining: " + (3 - attempts));
                }
            }
        }

        if (!success) {
            System.out.println("Too many failed attempts. Exiting.");
            scanner.close();
            return;
        }

        // --- PART 2 & 3: QUICKCHAT MENU ---
        System.out.println("\nWelcome to QuickChat.");
        
        boolean running = true;
        int numMessagesToSend = 0;
        int messagesSentCount = 0;

        while (running) {
            System.out.println("\n--- QuickChat Menu ---");
            System.out.println("1) Send Messages");
            System.out.println("2) Show recently sent messages");
            System.out.println("3) Quit");
            System.out.println("4) Stored Messages"); // NEW PART 3 OPTION
            System.out.print("Choose an option: ");
            
            String menuChoice = scanner.nextLine();

            switch (menuChoice) {
                case "1":
                    if (numMessagesToSend == 0) {
                        System.out.print("How many messages do you wish to enter? ");
                        try {
                            numMessagesToSend = Integer.parseInt(scanner.nextLine());
                        } catch (NumberFormatException e) {
                            System.out.println("Invalid number. Defaulting to 1.");
                            numMessagesToSend = 1;
                        }
                    }

                    if (messagesSentCount < numMessagesToSend) {
                        System.out.print("Enter recipient cell number (e.g., +27718693002): ");
                        String recipient = scanner.nextLine();

                        System.out.print("Enter message text (max 250 chars): ");
                        String msgText = scanner.nextLine();

                        if (msgText.length() > 250) {
                            System.out.println("Please enter a message of less than 250 characters.");
                            break; 
                        }

                        Message msg = new Message(messagesSentCount, recipient, msgText);

                        if (!msg.checkRecipientCell().equals("Cell phone number successfully captured.")) {
                            System.out.println(msg.checkRecipientCell());
                            break; 
                        }

                        System.out.println("\nMessage generated:");
                        System.out.println(msg.printMessages());

                        System.out.println("\nWhat would you like to do?");
                        System.out.println("1) Send Message");
                        System.out.println("2) Disregard Message");
                        System.out.println("3) Store Message to send later");
                        System.out.print("Choice: ");
                        int action = Integer.parseInt(scanner.nextLine());

                        String actionResult = msg.SentMessage(action);
                        System.out.println(actionResult);

                        // --- PART 3 ARRAY POPULATION ---
                        if (action == 1) {
                            StoredMessagesManager.sentMessages[StoredMessagesManager.sentCount++] = msg;
                            messagesSentCount++; 
                        } else if (action == 2) {
                            StoredMessagesManager.disregardedMessages[StoredMessagesManager.disregardCount++] = msg;
                        } else if (action == 3) {
                            StoredMessagesManager.storedMessages[StoredMessagesManager.storedCount++] = msg;
                        }
                        // ------------------------------

                        if (messagesSentCount >= numMessagesToSend) {
                            System.out.println("\nTotal messages sent: " + msg.returnTotalMessages());
                            numMessagesToSend = 0; 
                            messagesSentCount = 0;
                        }

                    } else {
                        System.out.println("You have reached your limit for this batch. Choose option 1 again to start a new batch.");
                    }
                    break;

                case "2":
                    System.out.println("Coming Soon.");
                    break;

                case "3":
                    System.out.println("Exiting QuickChat. Goodbye!");
                    running = false;
                    break;

                // --- NEW PART 3 SUB-MENU ---
                case "4":
                    boolean inSubMenu = true;
                    while (inSubMenu) {
                        System.out.println("\n--- Stored Messages Menu ---");
                        System.out.println("a. Display sender and recipient of all stored messages");
                        System.out.println("b. Display the longest stored message");
                        System.out.println("c. Search for a message ID");
                        System.out.println("d. Search for messages sent to a particular recipient");
                        System.out.println("e. Delete a message using the message hash");
                        System.out.println("f. Display a full report");
                        System.out.println("g. Back to Main Menu");
                        System.out.print("Choose an option: ");
                        String subChoice = scanner.nextLine().toLowerCase();

                        switch (subChoice) {
                            case "a": StoredMessagesManager.displaySendersAndRecipients(); break;
                            case "b": StoredMessagesManager.displayLongestMessage(); break;
                            case "c":
                                System.out.print("Enter Message ID: ");
                                StoredMessagesManager.searchByMessageID(scanner.nextLine());
                                break;
                            case "d":
                                System.out.print("Enter Recipient Number: ");
                                StoredMessagesManager.searchByRecipient(scanner.nextLine());
                                break;
                            case "e":
                                System.out.print("Enter Message Hash to delete: ");
                                StoredMessagesManager.deleteByHash(scanner.nextLine());
                                break;
                            case "f": StoredMessagesManager.displayReport(); break;
                            case "g": inSubMenu = false; break;
                            default: System.out.println("Invalid choice.");
                        }
                    }
                    break;
                // ----------------------------

                default:
                    System.out.println("Invalid option. Please choose 1, 2, 3, or 4.");
            }
        }

        scanner.close();
    }
}