/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.poepart1;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import java.io.FileReader;
import java.io.IOException;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;

public class StoredMessagesManager {
    
    // The required arrays for Part 3
    public static Message[] sentMessages = new Message[100];
    public static Message[] disregardedMessages = new Message[100];
    public static Message[] storedMessages = new Message[100];
    
    public static int sentCount = 0;
    public static int disregardCount = 0;
    public static int storedCount = 0;

    // Populate arrays with the exact test data from the brief
    public static void populateTestData() {
        sentMessages[sentCount++] = new Message(0, "+27834557896", "Did you get the cake?");
        storedMessages[storedCount++] = new Message(1, "+27838884567", "Where are you? You are late! I have asked you to be on time.");
        disregardedMessages[disregardCount++] = new Message(2, "+27834484567", "Yohoooo, I am at your gate.");
        sentMessages[sentCount++] = new Message(3, "0838884567", "It is dinner time !");
        storedMessages[storedCount++] = new Message(4, "+27838884567", "Ok, I am leaving without you.");
    }

    // Load JSON messages into the array
    public static void loadStoredMessagesFromJSON() {
        Gson gson = new GsonBuilder().setPrettyPrinting().create();
        try (FileReader reader = new FileReader("messages.json")) {
            Type listType = new TypeToken<ArrayList<Message>>(){}.getType();
            List<Message> loaded = gson.fromJson(reader, listType);
            if (loaded != null) {
                for (Message m : loaded) {
                    if (storedCount < storedMessages.length) {
                        storedMessages[storedCount++] = m;
                    }
                }
                System.out.println(loaded.size() + " messages loaded from JSON into array.");
            }
        } catch (IOException e) {
            // Silently handle if file doesn't exist yet
        }
    }

    // 2a. Display sender and recipient
    public static void displaySendersAndRecipients() {
        System.out.println("\n--- Senders and Recipients of Stored Messages ---");
        for (int i = 0; i < storedCount; i++) {
            System.out.println("Recipient: " + storedMessages[i].getRecipient());
        }
    }

    // 2b. Display longest message
    public static void displayLongestMessage() {
        String longest = "";
        for (int i = 0; i < storedCount; i++) {
            if (storedMessages[i].getMessageText().length() > longest.length()) {
                longest = storedMessages[i].getMessageText();
            }
        }
        System.out.println("\nLongest stored message: \"" + longest + "\"");
    }

    // 2c. Search by Message ID
    public static void searchByMessageID(String id) {
        boolean found = false;
        for (int i = 0; i < storedCount; i++) {
            if (storedMessages[i].getMessageID().equals(id)) {
                System.out.println("Recipient: " + storedMessages[i].getRecipient());
                System.out.println("Message: " + storedMessages[i].getMessageText());
                found = true;
                break;
            }
        }
        if (!found) System.out.println("Message ID not found.");
    }

    // 2d. Search by Recipient
    public static void searchByRecipient(String recipient) {
        boolean found = false;
        System.out.println("\nMessages for " + recipient + ":");
        for (int i = 0; i < storedCount; i++) {
            if (storedMessages[i].getRecipient().equals(recipient)) {
                System.out.println("- " + storedMessages[i].getMessageText());
                found = true;
            }
        }
        if (!found) System.out.println("No messages found for this recipient.");
    }

    // 2e. Delete by Hash
    public static void deleteByHash(String hash) {
        boolean found = false;
        for (int i = 0; i < storedCount; i++) {
            if (storedMessages[i].getMessageHash().equals(hash)) {
                System.out.println("Message: \"" + storedMessages[i].getMessageText() + "\" successfully deleted.");
                for (int j = i; j < storedCount - 1; j++) {
                    storedMessages[j] = storedMessages[j + 1];
                }
                storedMessages[storedCount - 1] = null;
                storedCount--;
                found = true;
                break;
            }
        }
        if (!found) System.out.println("Hash not found.");
    }

    // 2f. Display full report
    public static void displayReport() {
        System.out.println("\n--- FULL STORED MESSAGES REPORT ---");
        for (int i = 0; i < storedCount; i++) {
            System.out.println("Message Hash: " + storedMessages[i].getMessageHash());
            System.out.println("Recipient: " + storedMessages[i].getRecipient());
            System.out.println("Message: " + storedMessages[i].getMessageText());
            System.out.println("-------------------------");
        }
    }
}
