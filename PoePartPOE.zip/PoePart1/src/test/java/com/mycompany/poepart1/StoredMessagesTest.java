/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */

package com.mycompany.poepart1;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class StoredMessagesTest {

    @BeforeEach
    public void setUp() {
        // Reset arrays before each test
        StoredMessagesManager.sentCount = 0;
        StoredMessagesManager.storedCount = 0;
        StoredMessagesManager.disregardCount = 0;
        
        // Load the test data
        StoredMessagesManager.populateTestData();
    }

    @Test
    public void testSentMessagesArrayPopulated() {
        assertEquals(2, StoredMessagesManager.sentCount);
        assertEquals("Did you get the cake?", StoredMessagesManager.sentMessages[0].getMessageText());
        assertEquals("It is dinner time !", StoredMessagesManager.sentMessages[1].getMessageText());
    }

    @Test
    public void testLongestMessage() {
        // The longest message in the test data is from Message 2
        String expected = "Where are you? You are late! I have asked you to be on time.";
        String longest = "";
        for (int i = 0; i < StoredMessagesManager.storedCount; i++) {
            if (StoredMessagesManager.storedMessages[i].getMessageText().length() > longest.length()) {
                longest = StoredMessagesManager.storedMessages[i].getMessageText();
            }
        }
        assertEquals(expected, longest);
    }

    @Test
    public void testSearchByRecipient() {
        // Check if we can find the messages for +27838884567
        String recipientToFind = "+27838884567";
        int foundCount = 0;
        
        for (int i = 0; i < StoredMessagesManager.storedCount; i++) {
            if (StoredMessagesManager.storedMessages[i].getRecipient().equals(recipientToFind)) {
                foundCount++;
            }
        }
        // There are 2 messages for this recipient in the test data
        assertEquals(2, foundCount);
    }

    @Test
    public void testDeleteByHash() {
        int initialCount = StoredMessagesManager.storedCount;
        String hashToDelete = StoredMessagesManager.storedMessages[0].getMessageHash();
        
        StoredMessagesManager.deleteByHash(hashToDelete);
        
        // Count should decrease by 1
        assertEquals(initialCount - 1, StoredMessagesManager.storedCount);
    }
}